<?php
/**
 * Plugin Name: Single Category Purchase Restriction
 * Plugin URI: https://wordpress.org/plugins/single-category-purchase-restriction/
 * Description: Restricts the purchase of more than one product from a specific category in WooCommerce.
 * Author: Akash das
 * Author URI: https://dev-akash24.pantheonsite.io/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Version: 1.0.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Text Domain: scpra
 */

// Admin Page Setup
function scpra_add_theme_page() {
    add_menu_page('Single Category Purchase Restriction', 'Category purchase', 'manage_options', 'scpra-plugin-option', 'scpra_create_page', 'dashicons-pressthis', 101);
}
add_action('admin_menu', 'scpra_add_theme_page');

// admin page css

function add_scpra_admin_css(){

    wp_enqueue_style('scpra_admin_css',plugins_url('css/scpra-admin-style.css',__FILE__),false,'1.0.0');
};


add_action('admin_enqueue_scripts','add_scpra_admin_css');

function scpra_create_page() {
    ?>
    <div class="scpra_main_area">
        <div class="scpra_body_area">
            <h3 id="title"><?php echo esc_html('Single Category Purchase Restriction Customizer') ?></h3>
            <form method="post" action="options.php">
                <?php wp_nonce_field('update-options'); ?>

                <!-- Category ID Input -->
                <label for="scpra_category_id" name="scpra_category_id"><?php echo esc_html('Category ID') ?></label>
                <input placeholder="Category ID" type="text" name="scpra_category_id" value="<?php echo esc_attr(get_option('scpra_category_id')); ?>">

                <!-- Notice Text Input -->
                <label for="scpra_notice_text" name="scpra_notice_text"><?php echo esc_html('Notice Text') ?></label>
                <small><?php echo esc_html('Notice text links: You can only purchase one product from this (category name) category.') ?></small>
                <textarea placeholder="Notice Text" id="scpra_notice_text" class="large-text code" name="scpra_notice_text" rows="3"><?php echo esc_textarea(get_option('scpra_notice_text')); ?></textarea>

                <!-- Hidden Fields -->
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="page_options" value="scpra_category_id,scpra_notice_text">

                <!-- Submit Button -->
                <input class="button button-primary" type="submit" name="submit" value="<?php _e('Save Changes', 'scpra') ?>">
            </form>
        </div>
    </div>
    <?php
}

// Sanitize and Save Options
// Sanitize and Save Options
function scpra_save_options() {
    if (isset($_POST['submit'])) {
        update_option('scpra_category_id', sanitize_text_field($_POST['scpra_category_id']));
        update_option('scpra_notice_text', sanitize_textarea_field($_POST['scpra_notice_text']));
    }
}
add_action('admin_init', 'scpra_save_options');



// Cart Notice Function
function scpra_custom_cart_notice() {
    $allowed_category_id = get_option('scpra_category_id');
    $cart = WC()->cart;
    $allowed_category_products = array();

    foreach ($cart->get_cart() as $cart_item) {
        $product_id = $cart_item['product_id'];
        $product_categories = get_the_terms($product_id, 'product_cat');

        if ($product_categories && !is_wp_error($product_categories)) {
            foreach ($product_categories as $product_category) {
                if ($product_category->term_id == $allowed_category_id) {
                    $allowed_category_products[] = $product_id;
                    break; // No need to check other categories for the same product
                }
            }
        }
    }

    if (count($allowed_category_products) > 1) {
        $notice_text = get_option('scpra_notice_text');
        wc_add_notice($notice_text, 'error');
    }
}
add_action('woocommerce_check_cart_items', 'scpra_custom_cart_notice');



/*
*Plugin redirect Feature
*/

register_activation_hook(__FILE__,'scpra_plugin_activation');
function scpra_plugin_activation(){
    add_option('scpra_plugin_do_activation_redirect',true);
}

add_action('admin_init','scpra_plugin_redirect');

function scpra_plugin_redirect(){
    if(get_option('scpra_plugin_do_activation_redirect',false)){
        delete_option('scpra_plugin_do_activation_redirect');
        if(!isset($_GET['active-multi'])){
            wp_safe_redirect(admin_url('admin.php?page=scpra-plugin-option'));
            exit;
        }
    }
}


?>